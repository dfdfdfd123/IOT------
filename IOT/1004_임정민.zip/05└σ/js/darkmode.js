const bttn = document.querySelector("button");

bttn.onclick = function() {
  document.body.classList.toggle("dark")
}