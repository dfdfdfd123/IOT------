var hi = "hello"; // 전역 변수, 변수 선언

function greeting()
{
  console.log(hi);
}

greeting();