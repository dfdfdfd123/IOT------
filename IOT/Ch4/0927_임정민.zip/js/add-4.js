// 익명 함수 : 변수에 할당, 하나의 값처럼 사용.

let sum = function(a, b)
{
  return a + b;
}

console.log(`함수 실행 결과 : ${sum(10,20)}`);