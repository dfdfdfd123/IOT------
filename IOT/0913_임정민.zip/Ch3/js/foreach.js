const students = ["김유빈", "박동혁", "이재건", "최윤호"];

students.forEach(function(student)
{
  document.write(`${student} <br> `)
});