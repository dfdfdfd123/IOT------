// 배열에 친구 이름 4명 저장

const students = ["김유빈", "박동혁", "이재건", "최윤호"];

for(let student of students)
{
  document.write(`${student}. <br> `)
}