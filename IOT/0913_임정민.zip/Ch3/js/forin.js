const student = {
  major : "컴퓨터공학부",
  idNum : 201895079,
  name : '임정민'
}

for (key in student)
{
  document.write(`${key} : ${gitBook[key]} <br>`);
}