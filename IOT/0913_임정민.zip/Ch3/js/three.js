let three = parseInt(prompt("배수를 입력하세요"));
let str;



 if (three % 3 === 0) 
{
  str="3의 배수 입니다.";
}

else  {
  str="3의 배수가 아닙니다.";
}


alert(str);